﻿using System;


namespace CastleWisdor
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Registration registration = new Registration();

            var container = registration.RegisterContainer();

            var root = container.Resolve<ICompositionRoot>();

            root.LogMessage("Hello from my very first resolved class!");

            Console.ReadLine();
        }
    }
}
